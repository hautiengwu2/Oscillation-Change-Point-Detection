##################
# Helpers
##################


# Input
# x : a vector
# i : index position 
# omega : bandwidth (\tilde{m} in the paper)
# w : frequency used for Fourier transform
# Outout
# take the phase ajusted partial fourier transform of m points of x directly right of i 
# subtracts by m points left of i

dif <- function(i,x,m,omega){
  sum(x[(i-m):i] *exp(1i*2*pi*omega*((-m):(0)) ) ) -
    sum(x[(i+1):(i+m+1)]*exp(1i*2*pi*omega*(1:(m+1)) ) )
}

# Input
# x : a vector
# m : bandwidth
# omega : frequency used for Fourier transform
# Outout
# Compute for \Gamma_{i,i} for all psoition i in [m+1,n-m+1],

get_aggre_s2 <- function(x,m,omega){
  n = length(x)
  sapply(seq(m+1,n-m-1,1),function(i) dif(i =i, x =x,m=m,omega))
}

###################
# Get test Statistics
###################

# Input
# data : a vector
# m1 : bandwidth; \tild{m}
# m2 : bandwidth; m'
# omega : frequency used for Fourier transform
# Outout
# a vector of test statistic corresponding to the time position

get_t_s2<- function(data,m1,m2,omega){
  n = length(data)
  abs(sapply((m1+m2+1):(n-(m1+m2)-2), function(i) dif(i,x = data,m=m1,omega)))/sqrt(2*m1)
}

###################
# Get simulated critical Values Statistics
###################

###calculating block sums
blksum<-function(x,m)
{l=length(x)
y<-c(0,cumsum(x))
return(y[(m+1):(l+1)]-y[1:(l-m+1)])	
	}

####################################################################################
# same function as before but note  \Gamma_{i,j} = \exp(\sqrt{-1}w(i-j)) \Gamma_{i,i}
#  and  \sum_i \Gamma_{i,j} G_{i,l} = \sum_i \exp(\sqrt{-1}w(i-j)) \Gamma_{i,i} G_{i,l} 
####################################################################################

# Input
# x : a vector
# m1 : bandwidth; \tild{m}
# m2 : bandwidth; m'
# omega : frequency used for Fourier transform
# Output
# a vector of simulated statistic corresponding to the time position

########The phase-unadjusted Gamma
uGa<-function(x,m2,omega){
n=length(x)		
xf<-x*exp(1i*2*pi*omega*(0:(n-1)))	
y<-blksum(xf,(m2+1))
l=length(y)
return((y[(m2+2):l]-y[1:(l-m2-1)])/sqrt(2*m2))	
}

# Get multiplier bootstrap statistics (one repetition)
get_sim1_s2 <- function(x,m1,m2,omega){
Ga<-uGa(x,m2,omega)
l=length(Ga)
y<-blksum(Ga*rnorm(l),m1+1)
l1<-length(y)
return(abs(y[(m1+2):l1]-y[1:(l1-m1-1)])/sqrt(2*m1))
}

# Get multiplier bootstrap statistics (multiple repetition)
# length of K is the number of repititions
get_sim_s2 <- function(x,m1,m2,omega,K=rep(1,1000)){
t(sapply(K,function(K) get_sim1_s2(x,m1,m2,omega)))
}


###################
# Get frequency index
###################

#same function  as first stage estimation process 
#replace frequency with time index

# Inputs :
# wh : set of significant estimates 
# w : the set of locations for estimation 
# d : size of points taken out from w (d=\tilde{m})
# Outputs : Output the set of remianing locations after removing its d nearest neighbours


get_location_s2 <- function(wh,w,d){
  q = NULL
  if(length(wh) ==1){
    q = max( c(wh -d),1 ):min(c(wh+d),length(w))
  } else {
    for(i in 1:length(wh) ) q = 
        c(q,(max( c(wh[i] -d),1 ):min(c(wh[i]+d),length(w) )) )
  }
  (1:length(w))[-unique(q)]
}


###################
# Get estimates
###################

#same function  as first stage estimation process 
#replace frequency with time index

# Inputs :
# t :test statistics (get from function get_t_s2)
# simt : multiplier bootstrap statistic (get from function get_sim_s2)
# n : sample size; 
# w : the set of locations for estimation (m1+m2+1: n-m1-m2-2)
# nf : maximum number of times of repeating the estimation process
# d : size of points taken out from w (m1)
# alpha : significance level
# Outputs : number of chnage points estimted and Set of change point estimates

get_estimate_s2 <- function(t,simt,n,w,nf,d,alpha){
  
  # ifr : index of the location set w
  ifr = 1:length(w)
  # ihw : index for estimated break points
  ihw = NULL
  # tst : test statistics ; crt : critcal value 
  # k : tracks number of times the estimation is performed  
  tst = 1 ;crit = 0 ; k = 0
  
  while((tst > crit) &(k< (nf) ) ){
    tst <- max(t[ifr])
    crit <- quantile(apply(simt[,ifr],1,max),(1-alpha),names = F)
    if (tst > crit) {
      k = k+1
      ihw <- c(ihw, min(which(t == max (t[ifr]) )) )
      ifr <- get_location_s2(ihw,w,d )
    }
  }
  # Output
  list(k=k,index=w[ihw],a=rep(NA,(nf - length(ihw) ) ) )
}

