








## loading the first EEGH channel (from case 01)
#stage <- read.csv("STAGE.csv",header = F,skip = 1)
data1 <- read.csv(file = "c4a1.csv",header = F,skip = 1) 
y <- data1[,1]


## example 2 :  s = 1510

##  selcting a segment of of EEG signal 10sec in length
#example 2 :  s = 1510

# s;e are intial/end position of the signal on the stage annointed time scale
s = 1510 ; e = s + 10
# st;(s+n)  are intial/end position of the signal on the stage annointed time scale
st = s*200 ; n = 2e3
seg = seq(st,st+n,1)

# px :  EEG signal 10sec in length starting at st
px <- y[seq(st,st+n,1)] 

## Selecting a set of frequency for analysis 

## Data processing
#px <- y[seq(st,st+n,1)] 

## Taking first order differencing data to eliminate drift effect
## remove the effect of statistic blows up at low frequencies
dpx <- px[2:(n+1)] - px[1:n]

# normalizing the data
# x : data after processing
x <- ( dpx - mean(dpx))/sd(dpx)

# w : selected set of frequencies in unit of (2\pi * n)
# w in between (1,n) 
# w also can be interpreted as number of revolution per (10seconds)
# w /(10s) is in Hz 
w = seq(1,floor(n/8) ,1)


#p: size of frequency set w
p =length(w) 

# m : the stage 1 bandwidth parameter; note m here is half that of bandwidth m in paper
#omega<-2*pi*w/n
#yy<-matrix(0,2*length(omega),n)

#for(i in 1:length(omega)){
#yy[i,]=x*cos(omega[i]*(1:n))
#yy[i+length(omega),]=x*sin(omega[i]*(1:n))
#}
#band1<-multi_bandselect(yy, cut=3)
#band1=14
#m=band1

m=14


#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#start
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




## get the test statistics by frequencies # refer "s1_functions.R"'
# L : test statistics by frequencies ; L is vector size p  
# not normalized  
L <- get_t_s1(x,w) 

## get simulated bootstrap statistics

# E : data aggregate at bandwidth m 
#E <- sapply(w, function(w) get_agre(x = (x*exp(1i*2*pi*w*(0:(n-1))/n)),m))

# simt1 : matrix of bootstrap statistics; each row represents a repetition 
# each column is a frequency matching  
# not normalized  
# k : number of repeatition for bootstrap simulation simulation 
k = 1000
simt1 = matrix( rep(0,k*p),nrow = k)
for(j in 1:k) {
  simt1[j,] <- get_sim1(x,w,m)
}

## get frequency estimation from test statisic and simulations bootstrap statistics
# est : estimates at significance level  'sig'
nf = 3 
sig = 0.1
est <- get_estimate(L ,simt1,n,w ,nf = nf,d = m,alpha = sig)

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#end
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# loop code between start and end for simulation     #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

## data plot ; EEG signal
#postscript("DA_signal_new.eps")
plot( (1:length(seg))/200 ,(px-33770.8)/143.6,type = "l",
      xlab = "Time (sec)", ylab = expression( paste("Amplitude (",mu,"V)")),cex.lab=1.3,cex.axis=1.3)
#dev.off()      

## Stage1 statistics plot
#est[2:4]/n * 200
crit <- quantile(apply(simt1[,w],1,max),(1 - sig ),names = F)/
  sqrt(m*(n-m-1))
w = seq(1,floor(n/8) ,1)
#postscript("DA_stage1_new.eps")
plot(w/n*200,L/sqrt(n),type = "l", ylim = c(0,(crit + 0.5)),
     xlab = "Frequency (Hz)",ylab="Test Statistics",cex.lab=1.1,cex.axis=1.1)
abline(h = crit,col = 2)
#dev.off()
##########NULL CASE
s = 1530 ; e = s + 10

st = s*200 ; n = 2e3
seg = seq(st,st+n,1)

# px :  EEG signal 10sec in length starting at st
px <- y[seq(st,st+n,1)]

dpx <- px[2:(n+1)] - px[1:n]

# normalizing the data
# x : data after processing
x <- ( dpx - mean(dpx))/sd(dpx)

w = seq(1,floor(n/8) ,1)


#p: size of frequency set w
p =length(w) 

# m : the stage 1 bandwidth parameter; note m here is half that of bandwidth m in paper
#omega<-2*pi*w/n
#yy<-matrix(0,2*length(omega),n)

#for(i in 1:length(omega)){
#yy[i,]=x*cos(omega[i]*(1:n))
#yy[i+length(omega),]=x*sin(omega[i]*(1:n))
#}
#band1<-multi_bandselect(yy, cut=3)
#m=band1

m=9

L <- get_t_s1(x,w) 

k = 1000
simt12 = matrix( rep(0,k*p),nrow = k)
for(j in 1:k) {
  simt12[j,] <- get_sim1(x,w,m)
}


nf = 3 
sig = 0.1
est1 <- get_estimate(L ,simt12,n,w ,nf = nf,d = m,alpha = sig)


postscript("NULL_signal_new.eps")
plot( (1:length(seg))/200 ,(px-33770.8)/143.6,type = "l",
      xlab = "Time (sec)", ylab = expression( paste("Amplitude (",mu,"V)")),cex.lab=1.3,cex.axis=1.3)
dev.off()   

crit1 <- quantile(apply(simt12[,w],1,max),(1 - sig ),names = F)/
  sqrt(m*(n-m-1))

postscript("NULL_stage1_new.eps")
plot(w/n*200,L/sqrt(n),type = "l", ylim = c(0,(crit1 + 0.5)),
     xlab = "Frequency (Hz)",ylab="Test Statistics",cex.lab=1.3,cex.axis=1.3
)
abline(h = crit1,col = 2)
dev.off()   


