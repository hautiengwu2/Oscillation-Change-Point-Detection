## stage 2  estimatimation for change points

###################################
#read in the same data as stage 1 #
###################################

# stage <- read.csv("STAGE.csv",header = F,skip = 1)
data1 <- read.csv(file = "c4a1.csv",header = F,skip = 1) 
y <- data1[,1]
s = 1510 ; e = s + 10
st = s*200 ; n = 2e3
seg = seq(st,st+n,1)
px <- y[seq(st,st+n,1)] 
dpx <- px[2:(n+1)] - px[1:n]
x <- ( dpx - mean(dpx))/sd(dpx)


## get helper function for stage 2 estimation
#source("s2_functions.R")

# hw : estimated frequency from stage 1
hw = est[2]/n
#here hw=0.0705

#yy<-matrix(0,2*length(hw),n)

#for(i in 1:length(hw)){
#yy[i,]=x*cos(2*pi*hw[i]*(1:n))
#yy[i+length(hw),]=x*sin(2*pi*hw[i]*(1:n))
#}
#band2<-s2bandselect(yy, cut=2)
band2=13
m2=band2

#bbb<-pselect(x=x,m2=m2,omega=hw)
# m1 : \tilde{m}, bandwidth parameter
#m1<-bbb$m1[24]
m1=112
# m2 : m' ,bandwidth parameter
#m2 = 13
# k :number of repeatition for bootstrap simulation
k = 1e3



#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#start                                               #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



omega=hw
simt_s2<-get_sim_s2(x,m1,m2,omega)

test<-get_t_s2(x,m1,m2,omega)

boots1<-apply(simt_s2,1,max)
crit2<-sort(boots1)[0.95*length(boots1)]

w<-((m1+m2+1): (n-m1-m2-2))
nf=6
d=m1
aaa<-get_estimate_s2(t=test,simt=simt_s2,n=n,w=w,nf=nf,d=d,alpha=0.05)
aaa$index
# 696 1019  905
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#end                                                 #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# loop code between start and end for simulation     #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


brk1=696
brk2=1019
brk3=905


# plot test statistics along with critical value 
postscript("DA_stage2_new.eps")
plot( w/200 ,test,type = "l",
      xlab = "Time (sec)",ylab= "Test Statistics",cex.lab=1.25,cex.axis=1.3)
abline(h = crit2,col=2)
dev.off() 

## plot time portion of the EEG signal between break points
postscript("DA_signal_annotated_new.eps")
plot((1:length(seg))/200 ,(px-33770.8)/143.6,type = "l", xlab = "Time (sec)"
     , ylab = expression( paste("Amplitude (",mu,"V)")),cex.lab=1.25,cex.axis=1.3 )
lines( (brk1:brk2)/200,((px[brk1:brk2]-33770.8)/143.6),col = 2  )
dev.off()


