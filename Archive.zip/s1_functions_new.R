


##################
# Helpers        #
##################

# Input
# x : a vector
# Outout
# maximum of absolute value of cumsum statistics of x

cs_s1 <-function(x){
  max(abs(cumsum( x )))
}


# Input
# x : a vector
# i : index position 
# m : bandwidth
# Outout
# take the sum of m data points directly right of i and m points left of i

agre <- function(i,x,m){
  sum(x[i:(i+m-1)])
}

# Input
# x : a vector
# m : bandwidth
# Outout
# get the aggregates for bootstrap

get_agre <- function(x,m){
  n = length(x)
  sapply((1):(n-m+1),function(i) agre(i =i, x =x,m=m))
}

###################
# Get test Statistics
# w is the set of candididate frequencies. w should be a vector.
###################
get_t_s1 <- function(data,w){
  n = length(data)
  sapply(w,function(w) cs_s1(x=data*exp(1i*2*pi*w*(0:(n-1))/n)))
}

###################
# Get multiplier bootstrap statistics (one repetition)
# x is the data vector
# m is the bandwidth for the bootstrap
# w is the set of candididate frequencies. w should be a vector.
###################
get_sim1 <- function(x,w,m){
	n=length(x)
	y<-sapply(w,function(w) get_agre(x=x*exp(1i*2*pi*w*(0:(n-1))/n),m=m))
  Sm = y*rnorm(n =  nrow(y) ,mean = 0,sd = 1)
  apply(Sm,2,cs_s1)
}

###################
# Get multiplier bootstrap statistics (multiple repetition)
# x is the data vector
# m is the bandwidth for the bootstrap
# length of K is the number of repititions
# w is the set of candididate frequencies. w should be a vector.
###################
#get_sim <- function(x,w,m,K=1000){
#Re<-NULL
#for (i in 1:K)
#Re<-rbind(Re,get_sim1(x,w,m))
#return(Re)
#}
get_sim <- function(x,w,m,K=rep(1,1000)){
t(sapply(K,function(K) get_sim1(x,w,m)))
}

###################
# Get frequency index
###################

# Inputs :
# wh : set of significant estimates 
# w : the frequency set for estimation 
# d : size of points taken out from w
# Outputs : Output the set of remianing frequencies after removing its d nearest neighbours


get_freq<-function(wh,w,d){
  q = NULL
  if(length(wh) ==1){
    q = max( c(wh -d),1 ):min(c(wh+d),length(w))
  } else {
    for(i in 1:length(wh) ) q = 
        c(q,(max( c(wh[i] -d),1 ):min(c(wh[i]+d),length(w) )) )
  }
  (1:length(w))[-unique(q)]
}

###################
# Get estimates   #
###################

# Inputs :
# t :test statistics (from function get_t_s1)
# simt : multiplier bootstrap statistics (from function get_sim)
# n : sample size; 
# w : the frequency set for estimation 
# nf : maximum number of times of repeating the estimation process
# d : size of points taken out from w at each step (log (m)/(4m^(1/2)) in lebsegue length)
# alpha : significance level
# Outputs : number of frequencies estimted and Set of frequency estimates

get_estimate <- function(t,simt,n,w,nf,d,alpha){
  
  # ifr : w[ifr]  is the same as  W_k ; abbreviates for index of frequency remaining 
  ifr = 1:length(w)
  # ihw : index for estimated frequencies; w[ihw] is the set of \hat{W}
  ihw = NULL
  # tst : test statistics ; crt : critcal value 
  # k : tracks number of times the estimation is performed  
  tst = 1 ;crit = 0 ; k = 0
  
  while((tst > crit) &(k< (nf) ) ){
    tst <- max(t[ifr])/sqrt(n)
    crit <- quantile(apply(simt[,ifr],1,max),(1-alpha),names = F)/
      sqrt((m)*(n-m))
    if (tst > crit) {
      k = k+1
      ihw <- c(ihw, min(which(t == max (t[ifr]) )) )
      ifr <- get_freq(ihw,w,d )
    }
  }
  # Output
  c(k,w[ihw],rep(NA,(nf - length(ihw) ) ) )
}
