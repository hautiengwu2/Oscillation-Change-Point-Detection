###calculating block sums
blksum<-function(x,m)
{l=length(x)
y<-c(0,cumsum(x))
return(y[(m+1):(l+1)]-y[1:(l-m+1)])	
	}

##stage 1 variance estimation
vari<-function(x,m0,r){
S2m<-((blksum(x,m0)-m0*mean(x))/sqrt(m0))^2	
trans<-blksum(S2m,r)
g<-length(trans)
Hr<-(trans[(r+1):g]-trans[1:(g-r)])^2/(2*r)
return(sum(Hr)/((length(x)-m0-2*r+2)*m0))	
}

#######stage 2 variance estimation
s2vari<-function(x,mp,r){
l=length(x)-mp+1
s<-blksum(x,mp)
S2m<-(s[(mp+1):l]-s[1:(l-mp)])^2/(2*mp)	
trans<-blksum(S2m,r)
g<-length(trans)
Hr<-(trans[(r+1):g]-trans[1:(g-r)])^2/(2*r)
return(sum(Hr)/((l-mp-2*r+2)*mp))	
}




# stage 1 bias estimation
nbias<-function(x,cut=floor(length(x)^(1/6))){
sequ<-blksum(x,cut)
l<-length(sequ)
s1<-sequ[1:(l-2*cut)]
s2<-sequ[(1+cut):(l-cut)]
s3<-sequ[(1+2*cut):(l)]
return(2*mean((s1)*(s2-s3)))
}




#stage 2 bias estimation
ns2bias<-function(x,cut=floor(length(x)^(1/6))){
sequ<-blksum(x,cut)
l<-length(sequ)
s1<-sequ[1:(l-2*cut)]
s2<-sequ[(1+cut):(l-cut)]
s3<-sequ[(1+2*cut):(l)]

return(3*mean((s1)*(s2-s3)))
}

###plug-in block size selection
nbandselect<-function(x,m0=floor(length(x)^(1/3)),r=floor(length(x)^(1/3)),cut=floor(length(x)^(1/6))){
a1<-vari(x,m0=m0,r=r)
a2<-nbias(x,cut=cut)	
return(max(floor((2*a2^2/a1*length(x))^(1/3)),1))	
}


########stage 1 block size selection for multivariate time series
multi_bandselect<-function(x,m0=floor(dim(x)[2]^(1/3)),r=floor(dim(x)[2]^(1/3)),cut=floor(dim(x)[2]^(1/6))){
var1<-mean(apply(x,1,vari,m0=m0,r=r))	
bias2<-mean((apply(x,1,nbias,cut=cut))^2)
return(max(floor((2*bias2/var1*dim(x)[2])^(1/3)),1))
}	

########stage 2 block size selection
s2bandselect<-function(x,mp=floor(dim(x)[2]^(1/3)),r=floor(dim(x)[2]^(1/3)),cut=floor(dim(x)[2]^(1/6))){
var1<-mean(apply(x,1,s2vari,mp=mp,r=r))	
bias2<-mean((apply(x,1,ns2bias,cut=cut))^2)
return(max(floor((2*bias2/var1*dim(x)[2])^(1/3)),1))
}	

source("s1_functions.R")
source("s2_functions.R")
###############sum of squares for the residuals
######## y should be the fourier transform of x
##length of index set (ind) and m should be both larger than 1
SSE<-function(y,ind,m){
ms<-min(length(ind),m)	
z<-blksum(y,ms)/ms
start<-ind[1]
end=ind[(length(ind)-ms+1)]
ind2<-c(start:end,rep(end,ms-1))
return(sum(abs(y[ind]-z[ind2])^2))	
}

############penalized bandwidth selection of \tilde{m} in stage 2
# nf : maximum number of change points allowed
# omega : the estimated frequency
# m2 : the selected m'

pselect<-function(x,m2,omega,nf=floor(length(x)^(1/4))){
n=length(x)
m_smooth=floor(n^(2/3))
m1<-seq(floor(n^(16/29)),floor(n^(2/3)),by=2)	
l=length(m1)
fx<-x*exp(1i*2*pi*omega*(0:(n-1)))
n_change=rep(0,l)
location_change=matrix(0,l,nf)
pen=rep(0,l)
SS=rep(0,l)
for(i in 1:l){
tt<-get_t_s2(x,m1[i],m2,omega)
boots<-get_sim_s2(x,m1[i],m2,omega,K=rep(1,1000))
w<-((m1[i]+m2+1): (n-m1[i]-m2-2))	
d=m1[i]
y<-get_estimate_s2(t=tt,simt=boots,n=n,w=w,nf=nf,d=d,alpha=0.05)	
n_change[i]=y$k
if(y$k==0){
SS[i]=SSE(fx,1:n,m_smooth)
pen[i]=n*log(SS[i]/n)		
}
if(y$k!=0){
location_change[i,1:y$k]=sort(y$index)
inds<-c(1,sort(y$index),n)
for(j in 1:(y$k+1)){
indx=inds[j]:inds[j+1]
SS[i]=SS[i]+SSE(fx,indx,m_smooth)	
}
pen[i]=n*log(SS[i]/n)+log(n)*y$k
}
}
list(m1=m1,pen=pen,SS=SS,n_change=n_change,location_change=location_change)		
}



